package Question2;

public class ListNode {
	int value;
    ListNode next;

    ListNode(int value) {
        this.value = value;
        this.next = null;
    }

}
