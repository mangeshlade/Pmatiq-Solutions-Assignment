package Question2;

public class LinkedListCycleDetector {
    public static boolean hasCycle(ListNode head) {
        if (head == null) {
            return false;
        }

        ListNode slow = head;
        ListNode fast = head;

        while (fast != null && fast.next != null) {
            slow = slow.next;          // Move slow pointer by 1
            fast = fast.next.next;    // Move fast pointer by 2

            if (slow == fast) {
                return true;          // Cycle detected
            }
        }

        return false;                 // No cycle
    }

    public static void main(String[] args) {
        // Example 1: Create a linked list with a cycle
        ListNode head1 = new ListNode(20);
        head1.next = new ListNode(30);
        head1.next.next = new ListNode(40);
        head1.next.next.next = new ListNode(60);
        head1.next.next.next.next = new ListNode(80);
        head1.next.next.next.next.next = head1.next.next; // Creates a cycle

        // Example 2: Create a linked list without a cycle
        ListNode head2 = new ListNode(6);
        head2.next = new ListNode(4);
        head2.next.next = new ListNode(2);
        head2.next.next.next = new ListNode(8);

        // Test the function
        System.out.println("Has cycle in list 1: " + hasCycle(head1)); // Output: true
        System.out.println("Has cycle in list 2: " + hasCycle(head2)); // Output: false
    }
}

