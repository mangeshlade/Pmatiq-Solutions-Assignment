package Question1;
	import java.util.Arrays;

	public class ShippingOptimization {

	    public static void main(String[] args) {
	        // Example inputs
	        int[] shipments = {10, 20, 30};
	        int[] containerLimits = {15, 15, 20, 10};
	        
	        // Calculate and print the minimum number of containers needed
	        int result = minContainersNeeded(shipments, containerLimits);
	        System.out.println("Minimum number of containers needed: " + result);
	    }
	    
	    public static int minContainersNeeded(int[] shipments, int[] containerLimits) {
	        // Sort shipments in descending order
	        Arrays.sort(shipments);
	        // Sort containerLimits in ascending order
	        Arrays.sort(containerLimits);
	        
	        // Reverse shipments array to process the largest shipments first
	        reverseArray(shipments);
	        
	        int containersUsed = 0;
	        int containerIndex = 0;
	        
	        // Process each shipment
	        for (int shipment : shipments) {
	            while (shipment > 0) {
	                // If we've used all containers and still have shipment left
	                if (containerIndex >= containerLimits.length) {
	                    return -1; // Not enough capacity
	                }
	                
	                // Get the current container's capacity
	                int containerCapacity = containerLimits[containerIndex];
	                
	                if (containerCapacity >= shipment) {
	                    // If current container can handle the shipment
	                    containerLimits[containerIndex] -= shipment;
	                    shipment = 0;
	                } else {
	                    // Use up the current container and move to the next
	                    shipment -= containerCapacity;
	                    containerIndex++;
	                    containersUsed++;
	                }
	            }
	            
	            // If we used the last container, count it
	            if (containerIndex > 0 && containerLimits[containerIndex - 1] == 0) {
	                containersUsed++;
	            }
	        }
	        
	        // If containers were used, return the count, else -1 if no containers were used
	        return containersUsed > 0 ? containersUsed : -1;
	    }
	    
	    // Helper method to reverse an array
	    private static void reverseArray(int[] array) {
	        int left = 0;
	        int right = array.length - 1;
	        while (left < right) {
	            int temp = array[left];
	            array[left] = array[right];
	            array[right] = temp;
	            left++;
	            right--;
	        }
	    }
	}



